/**
 * define downloadSettingOptions 
 * 
 ***/
cr.define('options', function() {
    var OptionsPage = options.OptionsPage;

    function DownloadSettingOptions() {
        OptionsPage.call(this, 'downloadSetting', templateData.downloadSettingPageTabTitle, 'downloadSettingPage');
    }

    cr.addSingletonGetter(DownloadSettingOptions);
    
    DownloadSettingOptions.prototype = {
        __proto__: options.OptionsPage.prototype,

        initializePage: function(){
            OptionsPage.prototype.initializePage.call(this);  
            this.addEventListener('visibleChange', function (event) {
                tpGetInitOptionsData();
                tpGetInitDownloaderData();
            });
           }//initializePage
        };
    return {
        DownloadSettingOptions: DownloadSettingOptions
    };
});